Excuse my English.

This is alpha test release of Winsock2 API Delphi unit with two new capabilities:
- dynamic loading of WS2_32.DLL;
- WS2_32.DLL call tracing with filtering and packet dumping.

To turn on these capabilities
In Delphi IDE:
   Project -> Options -> Directories/Conditionals -> Conditional defines
   Add WS2_DLL_DYNAMIC_LOAD and/or WS2_DLL_TRACE (use semicolon as separator).
In dcc32.exe command line or <projectname>.cfg:
   Add switch -DWS2_DLL_DYNAMIC_LOAD and/or -DWS2_DLL_TRACE.

You can control tracing (if this option is enabled) in runtime by changing these
variables:

type
	TWS2TraceMaskBit = (
	trc_WSAStartup,trc_WSACleanup,trc_accept,trc_bind,trc_closesocket,
	trc_connect,trc_ioctlsocket,trc_getpeername,trc_getsockname,
	trc_getsockopt,trc_htonl,trc_htons,trc_inet_addr,trc_inet_ntoa,
	trc_listen,trc_ntohl,trc_ntohs,trc_recv,trc_recvfrom,trc_select,trc_send,
	trc_sendto,trc_setsockopt,trc_shutdown,trc_socket,trc_gethostbyaddr,
	trc_gethostbyname,trc_gethostname,trc_getservbyport,trc_getservbyname,
	trc_getprotobynumber,trc_getprotobyname,trc_WSASetLastError,
	trc_WSAGetLastError,trc_WSAIsBlocking,trc_WSAUnhookBlockingHook,
	trc_WSASetBlockingHook,trc_WSACancelBlockingCall,
	trc_WSAAsyncGetServByName,trc_WSAAsyncGetServByPort,
	trc_WSAAsyncGetProtoByName,trc_WSAAsyncGetProtoByNumber,
	trc_WSAAsyncGetHostByName,trc_WSAAsyncGetHostByAddr,
	trc_WSACancelAsyncRequest,trc_WSAAsyncSelect,trc___WSAFDIsSet,
	trc_WSAAccept,trc_WSACloseEvent,trc_WSAConnect,trc_WSACreateEvent ,
	trc_WSADuplicateSocket,trc_WSAEnumNetworkEvents,trc_WSAEnumProtocols,
	trc_WSAEventSelect,trc_WSAGetOverlappedResult,trc_WSAGetQosByName,
	trc_WSAHtonl,trc_WSAHtons,trc_WSAIoctl,trc_WSAJoinLeaf,trc_WSANtohl,
	trc_WSANtohs,trc_WSARecv,trc_WSARecvDisconnect,trc_WSARecvFrom,
	trc_WSAResetEvent,trc_WSASend,trc_WSASendDisconnect,trc_WSASendTo,
	trc_WSASetEvent,trc_WSASocket,trc_WSAWaitForMultipleEvents,
	trc_WSAAddressToString,trc_WSAStringToAddress,trc_WSALookupServiceBegin,
	trc_WSALookupServiceNext,trc_WSALookupServiceEnd,
	trc_WSAInstallServiceClass,trc_WSARemoveServiceClass,
	trc_WSAGetServiceClassInfo,trc_WSAEnumNameSpaceProviders,
	trc_WSAGetServiceClassNameByClassId,trc_WSASetService,
	trc_WSAProviderConfigChange
	);
	TWS2TraceMask = set of TWS2TraceMaskBit;
const
	WS2TraceAll = [Low(TWS2TraceMaskBit)..High(TWS2TraceMaskBit)];
var
	WS2TraceSwitch : Boolean = True; // Calls tracing on/off switch.
	WS2TraceRecvPackets : Boolean = False; // Received packet contents dumping.
	WS2TraceSendPackets : Boolean = False; // Sent packet contents dumping.
	WS2TraceMask : TWS2TraceMask = WS2TraceAll; // Trace filter mask.

Please email me your comments.

Alex Konshin

mailto:alexk@mtgroup.ru
http://www.mtgroup.ru/~alexk
FIDO 2:5030/217
ICQ 14240881
